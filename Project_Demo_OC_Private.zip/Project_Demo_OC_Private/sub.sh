#!/bin/bash


Cyan='\033[0;36m'
Default='\033[0;m'

author=""
projectName=""
httpsRepo=""
homePage=""
confirmed="n"
organizationName=""

# 模板工程clone地址
DemoClonePath='http://10.10.64.118/ios_PurangBrightSunnySky/Project_Demo_OC.git'
# 模板工程名
DemoName='Project_Demo_OC'

getProjectName() {
    read -p "请输入项目名: " projectName

    if test -z "$projectName"; then
        getProjectName
    fi
}

getAuthor() {
read -p "请输入作者名: " author

if test -z "$author"; then
getAuthor
fi
}

getOrganizationName() {
    read -p "请输入组织名: " organizationName

    if test -z "$organizationName"; then
        getOrganizationName
    fi
}

getHTTPSRepo() {
    read -p "请输入仓库HTTPS URL: " httpsRepo

    if test -z "$httpsRepo"; then
        getHTTPSRepo
    fi

    homePage=${httpsRepo%.git*}
}

getInfomation() {
    getProjectName
    getAuthor
    getOrganizationName
    getHTTPSRepo

    echo -e "\n${Default}================================================"
    echo -e "  Project Name       :  ${Cyan}${projectName}${Default}"
    echo -e "  Author             :  ${Cyan}${author}${Default}"
    echo -e "  Organization Name  :  ${Cyan}${organizationName}${Default}"
    echo -e "  HTTPS Repo         :  ${Cyan}${httpsRepo}${Default}"
    echo -e "  Home Page URL      :  ${Cyan}${homePage}${Default}"
    echo -e "================================================\n"
}

echo -e "\n"
while [ "$confirmed" != "y" -a "$confirmed" != "Y" ]
do
    if [ "$confirmed" == "n" -o "$confirmed" == "N" ]; then
        getInfomation
    fi
    read -p "确定? (y/n):" confirmed
done

#回到上级目录
cd ../
# 下载模板工程
git clone ${DemoClonePath}
# 主工程重新命名
mv "${DemoName}" "${projectName}"
# 打开工程
cd ${projectName}
mv "${DemoName}" "${projectName}"
mv "${DemoName}.podspec" "${projectName}.podspec"
mv "${DemoName}.xcodeproj" "${projectName}.xcodeproj"
# 打开工程文件夹
cd ${projectName}
mv "${DemoName}" "${projectName}"

#回到上级目录
cd ../

# 文件路径
licenseFilePath="./FILE_LICENSE"
gitignoreFilePath="./.gitignore"
specFilePath="./${projectName}.podspec"
readmeFilePath="./readme.md"
uploadFilePath="./upload.sh"
podfilePath="./Podfile"
pbxprojPath="./${projectName}.xcodeproj/project.pbxproj"
xcworkspacedataPath="./${projectName}.xcodeproj/project.xcworkspace/contents.xcworkspacedata"

# 修改文件内容
echo "editing..."

sed -i "" "s%${DemoName}%${projectName}%g"      "$gitignoreFilePath"
sed -i "" "s%${DemoName}%${projectName}%g"      "$readmeFilePath"
sed -i "" "s%${DemoName}%${projectName}%g"      "$uploadFilePath"
sed -i "" "s%${DemoName}%${projectName}%g"      "$podfilePath"
sed -i "" "s%${DemoName}%${projectName}%g"      "$xcworkspacedataPath"
sed -i "" "s%${DemoName}%${projectName}%g"      "$pbxprojPath"

sed -i "" "s%${DemoName}%${projectName}%g"      "$specFilePath"

sed -i "" "s%__HomePage__%${homePage}%g"        "$specFilePath"
sed -i "" "s%__HTTPSRepo__%${httpsRepo}%g"      "$specFilePath"

sed -i "" "s%wanglei%${author}%g"               "$specFilePath"
sed -i "" "s%PURANG%${organizationName}%g"      "$pbxprojPath"

sed -i "" "s%wanglei%${author}%g"               "$pbxprojPath"
sed -i "" "s%PURANG%${organizationName}%g"      "$pbxprojPath"

# BundleId修改
sed -i "" "s%Project-Demo-OC%${projectName}%g"  "$pbxprojPath"


echo "edit finished"

echo "cleaning..."

#移除模块原先git记录
rm -rf .git

git init
git remote add origin $httpsRepo  &> /dev/null
git rm -rf --cached ./Pods/     &> /dev/null
git rm --cached Podfile.lock    &> /dev/null
git rm --cached .DS_Store       &> /dev/null
git rm -rf --cached $projectName.xcworkspace/           &> /dev/null
git rm -rf --cached $projectName.xcodeproj/xcuserdata/`whoami`.xcuserdatad/xcschemes/$projectName.xcscheme &> /dev/null
git rm -rf --cached $projectName.xcodeproj/project.xcworkspace/xcuserdata/ &> /dev/null
echo "clean finished"
say "finished"
echo "finished"
